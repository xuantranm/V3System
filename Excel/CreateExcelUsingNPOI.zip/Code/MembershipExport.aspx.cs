﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using NPOI.HSSF.Util;
using NPOI.POIFS.FileSystem;
using NPOI.HPSF;

public partial class MembershipExport : System.Web.UI.Page
{
    protected void btnGenerateReport_Click(object sender, EventArgs e)
    {
        // Get the data to report on
        var userAccounts = Membership.GetAllUsers();

        // Create a new workbook and a sheet named "User Accounts"
        var workbook = new HSSFWorkbook();
        var sheet = workbook.CreateSheet("User Accounts");

        // Add header labels
        var rowIndex = 0;
        var row = sheet.CreateRow(rowIndex);
        row.CreateCell(0).SetCellValue("Username");
        row.CreateCell(1).SetCellValue("Email");
        row.CreateCell(2).SetCellValue("Joined");
        row.CreateCell(3).SetCellValue("Last Login");
        row.CreateCell(4).SetCellValue("Approved?");
        row.CreateCell(5).SetCellValue("Comments");
        rowIndex++;

        // Add data rows
        foreach (MembershipUser account in userAccounts)
        {
            row = sheet.CreateRow(rowIndex);
            row.CreateCell(0).SetCellValue(account.UserName);
            row.CreateCell(1).SetCellValue(account.Email);
            row.CreateCell(2).SetCellValue(account.CreationDate.ToShortDateString());
            row.CreateCell(3).SetCellValue(account.LastLoginDate.ToShortDateString());
            row.CreateCell(4).SetCellValue(account.IsApproved);
            row.CreateCell(5).SetCellValue(account.Comment);
            rowIndex++;
        }

        // Auto-size each column
        for (var i = 0; i < sheet.GetRow(0).LastCellNum; i++)
            sheet.AutoSizeColumn(i);


        // Add row indicating date/time report was generated...
        sheet.CreateRow(rowIndex + 1).CreateCell(0).SetCellValue("Report generated on " + DateTime.Now.ToString());


        // Use the following commented-out code to save the Excel spreadsheet to the web server's filesystem
        //using (var fileData = new FileStream(Server.MapPath(saveAsFileName), FileMode.Create))
        //{
        //    string saveAsFileName = string.Format("MembershipExport-{0:d}.xls", DateTime.Now).Replace("/", "-");
        //    
        //    workbook.Write(fileData);
        //}


        // Save the Excel spreadsheet to a MemoryStream and return it to the client
        using (var exportData = new MemoryStream())
        {
            workbook.Write(exportData);

            string saveAsFileName = string.Format("MembershipExport-{0:d}.xls", DateTime.Now).Replace("/", "-");

            Response.ContentType = "application/vnd.ms-excel";
            Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", saveAsFileName));
            Response.Clear();
            Response.BinaryWrite(exportData.GetBuffer());
            Response.End();
        }
    }
}