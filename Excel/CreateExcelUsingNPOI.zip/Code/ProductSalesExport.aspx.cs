﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.Linq;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using NPOI.HSSF.Util;
using NPOI.POIFS.FileSystem;
using NPOI.HPSF;

public partial class ProductSalesExport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            var context = new NorthwindDataContext();
            var distinctYearsAcrossAllOrders =
                        context.Orders
                               .Where(o => o.OrderDate.HasValue)
                               .Select(o => o.OrderDate.Value.Year)
                               .Distinct();

            ddlYears.DataSource = distinctYearsAcrossAllOrders.OrderBy(yr => yr);
            ddlYears.DataBind();
        }
    }

    protected void btnGenerateReport_Click(object sender, EventArgs e)
    {
        var yearSelected = Convert.ToInt32(ddlYears.SelectedValue);

        var context = new NorthwindDataContext();

        // Configure LINQ to use eager loading
        var options = new DataLoadOptions();
        options.LoadWith<Order_Detail>(od => od.Order);
        options.LoadWith<Order_Detail>(od => od.Product);
        context.LoadOptions = options;

        // Get the data to report on
        var detailedSales = context.Order_Details
                                   .Where(od => od.Order.OrderDate.HasValue && od.Order.OrderDate.Value.Year == yearSelected)
                                   .OrderBy(od => od.Product.ProductName).ThenBy(od => od.OrderID);

        var summarySales = detailedSales
                                   .GroupBy(od => od.Product.ProductName)
                                   .Select(grp => new
                                   {
                                       ProductName = grp.Key,
                                       TotalSales = grp.Sum(od => od.UnitPrice * od.Quantity)
                                   });


        // Create a new workbook
        var workbook = new HSSFWorkbook();

        #region Cell Styles
        #region HeaderLabel Cell Style
        var headerLabelCellStyle = workbook.CreateCellStyle();
        headerLabelCellStyle.Alignment = HorizontalAlignment.CENTER;
        headerLabelCellStyle.BorderBottom = CellBorderType.THIN;
        var headerLabelFont = workbook.CreateFont();
        headerLabelFont.Boldweight = (short)FontBoldWeight.BOLD;
        headerLabelCellStyle.SetFont(headerLabelFont);
        #endregion

        #region RightAligned Cell Style
        var rightAlignedCellStyle = workbook.CreateCellStyle();
        rightAlignedCellStyle.Alignment = HorizontalAlignment.RIGHT;
        #endregion

        #region Currency Cell Style
        var currencyCellStyle = workbook.CreateCellStyle();
        currencyCellStyle.Alignment = HorizontalAlignment.RIGHT;
        var formatId = HSSFDataFormat.GetBuiltinFormat("$#,##0.00");
        if (formatId == -1)
        {
            var newDataFormat = workbook.CreateDataFormat();
            currencyCellStyle.DataFormat = newDataFormat.GetFormat("$#,##0.00");
        }
        else
            currencyCellStyle.DataFormat = formatId;
        #endregion

        #region Detail Subtotal Style
        var detailSubtotalCellStyle = workbook.CreateCellStyle();
        detailSubtotalCellStyle.BorderTop = CellBorderType.THIN;
        detailSubtotalCellStyle.BorderBottom = CellBorderType.THIN;
        var detailSubtotalFont = workbook.CreateFont();
        detailSubtotalFont.Boldweight = (short)FontBoldWeight.BOLD;
        detailSubtotalCellStyle.SetFont(detailSubtotalFont);
        #endregion

        #region Detail Currency Subtotal Style
        var detailCurrencySubtotalCellStyle = workbook.CreateCellStyle();
        detailCurrencySubtotalCellStyle.BorderTop = CellBorderType.THIN;
        detailCurrencySubtotalCellStyle.BorderBottom = CellBorderType.THIN;
        var detailCurrencySubtotalFont = workbook.CreateFont();
        detailCurrencySubtotalFont.Boldweight = (short)FontBoldWeight.BOLD;
        detailCurrencySubtotalCellStyle.SetFont(detailCurrencySubtotalFont);
        formatId = HSSFDataFormat.GetBuiltinFormat("$#,##0.00");
        if (formatId == -1)
        {
            var newDataFormat = workbook.CreateDataFormat();
            detailCurrencySubtotalCellStyle.DataFormat = newDataFormat.GetFormat("$#,##0.00");
        }
        else
            detailCurrencySubtotalCellStyle.DataFormat = formatId;
        #endregion
        #endregion

        #region Summary sheet
        var sheet = workbook.CreateSheet("Summary");

        // And grand total row
        var row = sheet.CreateRow(0);
        var cell = row.CreateCell(0);
        cell.SetCellValue("Total Sales for " + yearSelected + ":");
        cell.CellStyle = headerLabelCellStyle;

        cell = row.CreateCell(1);
        cell.SetCellType(CellType.NUMERIC);
        cell.CellFormula = "SUM(B5:B999)";
        cell.CellStyle = currencyCellStyle;

        // Add header labels
        var rowIndex = 3;
        row = sheet.CreateRow(rowIndex);
        cell = row.CreateCell(0);
        cell.SetCellValue("Product");
        cell.CellStyle = headerLabelCellStyle;

        cell = row.CreateCell(1);
        cell.SetCellValue("Total Sales for " + yearSelected);
        cell.CellStyle = headerLabelCellStyle;
        rowIndex++;

        // Add data rows
        foreach (var productSummary in summarySales)
        {
            row = sheet.CreateRow(rowIndex);
            row.CreateCell(0).SetCellValue(productSummary.ProductName);

            cell = row.CreateCell(1);
            cell.SetCellType(CellType.NUMERIC);
            cell.SetCellValue((double) productSummary.TotalSales);
            cell.CellStyle = currencyCellStyle;
            rowIndex++;
        }

        // Auto-size each column
        for (var i = 0; i < sheet.GetRow(3).LastCellNum; i++)
        {
            sheet.AutoSizeColumn(i);

            // Bump up with auto-sized column width to account for bold headers
            sheet.SetColumnWidth(i, sheet.GetColumnWidth(i) + 1024);
        }


        // Add row indicating date/time report was generated...
        sheet.CreateRow(rowIndex + 1).CreateCell(0).SetCellValue("Report generated on " + DateTime.Now.ToString());
        #endregion


        #region Detail sheet
        sheet = workbook.CreateSheet("Details");

        // Add header labels
        rowIndex = 0;
        row = sheet.CreateRow(rowIndex);
        cell = row.CreateCell(0);
        cell.SetCellValue("Product");
        cell.CellStyle = headerLabelCellStyle;

        cell = row.CreateCell(1);
        cell.SetCellValue("Order");
        cell.CellStyle = headerLabelCellStyle;

        cell = row.CreateCell(2);
        cell.SetCellValue("Date");
        cell.CellStyle = headerLabelCellStyle;

        cell = row.CreateCell(3);
        cell.SetCellValue("Unit Price");
        cell.CellStyle = headerLabelCellStyle;

        cell = row.CreateCell(4);
        cell.SetCellValue("Quantity");
        cell.CellStyle = headerLabelCellStyle;

        cell = row.CreateCell(5);
        cell.SetCellValue("Total");
        cell.CellStyle = headerLabelCellStyle;
        rowIndex++;

        // Add data rows
        var lastProductName = string.Empty;
        var startRowIndexForProductDetails = 1;

        foreach (var productDetail in detailedSales)
        {
            // Show a summary row for each new product
            var productNameToShow = string.Empty;
            if (string.Compare(productDetail.Product.ProductName, lastProductName) != 0)
            {
                if (!string.IsNullOrEmpty(lastProductName))
                {
                    // Add the subtotal row
                    AddSubtotalRow(sheet, startRowIndexForProductDetails, rowIndex, detailSubtotalCellStyle, detailCurrencySubtotalCellStyle);
                    rowIndex += 3;
                }

                productNameToShow = productDetail.Product.ProductName;
                lastProductName = productDetail.Product.ProductName;
                startRowIndexForProductDetails = rowIndex;
            }

            row = sheet.CreateRow(rowIndex);
            row.CreateCell(0).SetCellValue(productNameToShow);
            row.CreateCell(1).SetCellValue(productDetail.OrderID);
            if (productDetail.Order.OrderDate.HasValue)
            {
                cell = row.CreateCell(2);
                cell.SetCellValue(productDetail.Order.OrderDate.Value.ToShortDateString());
                cell.CellStyle = rightAlignedCellStyle;
            }

            cell = row.CreateCell(3);
            cell.SetCellType(CellType.NUMERIC);
            cell.SetCellValue((double)productDetail.UnitPrice);
            cell.CellStyle = currencyCellStyle;

            row.CreateCell(4).SetCellValue(productDetail.Quantity);

            cell = row.CreateCell(5);
            cell.SetCellType(CellType.NUMERIC);
            cell.SetCellValue((double)productDetail.UnitPrice * productDetail.Quantity);
            cell.CellStyle = currencyCellStyle;
            rowIndex++;

        }

        // Add the subtotal row for the last product
        AddSubtotalRow(sheet, startRowIndexForProductDetails, rowIndex, detailSubtotalCellStyle, detailCurrencySubtotalCellStyle);
        rowIndex += 2;



        // Auto-size each column
        for (var i = 0; i < sheet.GetRow(0).LastCellNum; i++)
        {
            sheet.AutoSizeColumn(i);

            // Bump up with auto-sized column width to account for bold headers
            sheet.SetColumnWidth(i, sheet.GetColumnWidth(i) + 1024);
        }


        // Add row indicating date/time report was generated...
        sheet.CreateRow(rowIndex + 1).CreateCell(0).SetCellValue("Report generated on " + DateTime.Now.ToString());
        #endregion

        // Save the Excel spreadsheet to a MemoryStream and return it to the client
        using (var exportData = new MemoryStream())
        {
            workbook.Write(exportData);

            string saveAsFileName = string.Format("ProductSalesExport-{0}.xls", yearSelected);

            Response.ContentType = "application/vnd.ms-excel";
            Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", saveAsFileName));
            Response.Clear();
            Response.BinaryWrite(exportData.GetBuffer());
            Response.End();
        }
    }

    private void AddSubtotalRow(Sheet sheet, int startRowIndexForProductDetails, int rowIndex, CellStyle detailSubtotalCellStyle, CellStyle detailCurrencySubtotalCellStyle)
    {
        var row = sheet.CreateRow(rowIndex);
        var cell = row.CreateCell(0);
        cell.SetCellValue("Total:");
        cell.CellStyle = detailSubtotalCellStyle;

        cell = row.CreateCell(1);
        cell.CellStyle = detailSubtotalCellStyle;

        cell = row.CreateCell(2);
        cell.CellStyle = detailSubtotalCellStyle;

        cell = row.CreateCell(3);
        cell.SetCellType(CellType.FORMULA);
        cell.CellFormula = string.Format("SUM(D{0}:D{1})", startRowIndexForProductDetails + 1, rowIndex);
        cell.CellStyle = detailCurrencySubtotalCellStyle;

        cell = row.CreateCell(4);
        cell.SetCellType(CellType.FORMULA);
        cell.CellFormula = string.Format("SUM(E{0}:E{1})", startRowIndexForProductDetails + 1, rowIndex);
        cell.CellStyle = detailSubtotalCellStyle;

        cell = row.CreateCell(5);
        cell.SetCellType(CellType.FORMULA);
        cell.CellFormula = string.Format("SUM(F{0}:F{1})", startRowIndexForProductDetails + 1, rowIndex);
        cell.CellStyle = detailCurrencySubtotalCellStyle;
    }
}